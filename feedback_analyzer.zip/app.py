
from flask import Flask, request, jsonify, render_template
from textblob import TextBlob

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('feedback.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json()
    feedback = data.get('feedback', '')
    analysis = TextBlob(feedback)
    sentiment = 'Positive' if analysis.sentiment.polarity > 0 else 'Negative' if analysis.sentiment.polarity < 0 else 'Neutral'
    return jsonify({'sentiment': sentiment})

if __name__ == '__main__':
    app.run(debug=True)
