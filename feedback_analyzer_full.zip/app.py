
from flask import Flask, render_template, request
import pickle

# Load model and vectorizer
vectorizer, model = pickle.load(open("feedback_model.pkl", "rb"))

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("feedback.html")

@app.route('/predict', methods=['POST'])
def predict():
    feedback = request.form['feedback']
    vect = vectorizer.transform([feedback])
    pred = model.predict(vect)[0]

    labels = {0: "Negative 😡", 1: "Positive 😊", 2: "Neutral 😐"}
    result = labels[pred]

    return render_template("feedback.html", result=result)

if __name__ == '__main__':
    app.run(debug=True)
